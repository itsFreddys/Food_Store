public class MainStore {
    public static void main(String[] args) {
        System.out.println("Welcome to Best Food");
        Menu.printMenu();   // Calling the Menu
    }
}
